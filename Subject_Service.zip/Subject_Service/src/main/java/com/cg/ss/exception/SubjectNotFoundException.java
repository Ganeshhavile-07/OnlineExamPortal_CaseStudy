package com.cg.ss.exception;

@SuppressWarnings("serial")
public class SubjectNotFoundException extends Exception {

	public SubjectNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
