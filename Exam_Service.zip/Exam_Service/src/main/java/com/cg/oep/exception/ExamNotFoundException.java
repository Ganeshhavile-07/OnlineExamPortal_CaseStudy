package com.cg.oep.exception;

@SuppressWarnings("serial")
public class ExamNotFoundException extends Exception {

	public ExamNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
